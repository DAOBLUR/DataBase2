--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE negocios;
--
-- Name: negocios; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE negocios WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE negocios OWNER TO postgres;

\connect negocios

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: compras; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA compras;


ALTER SCHEMA compras OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: rrhh; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA rrhh;


ALTER SCHEMA rrhh OWNER TO postgres;

--
-- Name: ventas; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ventas;


ALTER SCHEMA ventas OWNER TO postgres;

--
-- Name: aumentar_precio_unitario(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.aumentar_precio_unitario()
    LANGUAGE plpgsql
    AS $$
declare
    cur cursor for ( select p.* from compras.productos p
        join compras.proveedores pr on pr.idproveedor = p.idproveedor
        join compras.categorias c on c.idcateria = p.idcateria
        where p.idproveedor in ( 1,2,3 ) and p.idcateria in ( 2,4,5 )
        group by p.idproducto
    );
    rec record;
begin
    open cur;
    loop
        fetch cur into rec;
        exit when not found;
        if rec.idproveedor = 1 and rec.idcateria = 4 then
        	raise notice 'update: %', rec.preciounidad * (1 + 0.1);
            update compras.productos set preciounidad = rec.preciounidad * (1 + 0.1)
            where idproducto = rec.idproducto;
        elsif rec.idproveedor = 3 and rec.idcateria = 2 then
        	raise notice 'update: %', rec.preciounidad * (1 + 0.15);
            update compras.productos set preciounidad = rec.preciounidad * (1 + 0.15)
            where idproducto = rec.idproducto;
        elsif rec.idproveedor = 2 and rec.idcateria = 5 then
        	raise notice 'update: %', rec.preciounidad * (1 + 0.2);
            update compras.productos set preciounidad = rec.preciounidad * (1 + 0.2)
            where idproducto = rec.idproducto;
        end if;
    end loop;
    close cur;
exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        rollback;
        return;
end;
$$;


ALTER PROCEDURE public.aumentar_precio_unitario() OWNER TO postgres;

--
-- Name: eliminar_cliente_sin_pedidos(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.eliminar_cliente_sin_pedidos(c_id character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
	delete from ventas.clientes where idcliente = c_id and 
	idcliente in ( select c.idcliente from Ventas.clientes c
		left join ventas.pedidoscabe p on c.IdCliente = p.IdCliente
		where p.IdPedido is null );
end;
$$;


ALTER FUNCTION public.eliminar_cliente_sin_pedidos(c_id character varying) OWNER TO postgres;

--
-- Name: eliminar_cliente_sin_pedidos2(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.eliminar_cliente_sin_pedidos2(c_id character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
    if not exists (
        select * from ventas.pedidoscabe where idcliente = c_id limit 1
    ) 
	then
        delete from ventas.clientes where idcliente = c_id;
        raise notice 'cliente eliminado: %', c_id;
    else
        raise notice 'no puede ser eliminado: %', c_id;
    end if;
end;
$$;


ALTER FUNCTION public.eliminar_cliente_sin_pedidos2(c_id character varying) OWNER TO postgres;

--
-- Name: mostrar_cargo_empleado_ventas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mostrar_cargo_empleado_ventas() RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
    cur_cargos cursor for ( select * from rrhh.cargos );
    rec_cargos record;
begin
    open cur_cargos;
    loop
        fetch cur_cargos into rec_cargos;
        exit when not found;
        raise notice '* CARGO: % , %', rec_cargos.idcargo, rec_cargos.descargo;

        declare
            cur_empleados cursor for ( select e.idempleado, e.apeempleado, e.nomempleado 
                from rrhh.empleados e where e.idcargo = rec_cargos.idcargo
            );
            rec_empleados record;
        begin
            open cur_empleados;
            loop
                fetch cur_empleados into rec_empleados;
                exit when not found;
                raise notice '  + EMPLEADO: % , % %', 
                    rec_empleados.idempleado, rec_empleados.nomempleado, rec_empleados.apeempleado;
                
                declare
                    cur_productos cursor for ( select p.idproducto, p.nomproducto
                        from compras.productos p 
                        join ventas.pedidosdeta pd on pd.idproducto = p.idproducto
                        join ventas.pedidoscabe pc on pc.idpedido = pd.idpedido
                        where pc.idempleado = rec_empleados.idempleado
                        group by p.idproducto, p.nomproducto
                        order by p.idproducto
                    );
                    rec_productos record;
                    producto_count int;
                begin
                    producto_count := 1;
                    open cur_productos;
                    loop
                        fetch cur_productos into rec_productos;
                        exit when not found;
                        raise notice '	  - PRODUCTO VENDIDO (%): % , %', producto_count, rec_productos.idproducto, rec_productos.nomproducto;
                        producto_count := producto_count + 1;
                    end loop;
                    close cur_productos;
                end;
            end loop;
            close cur_empleados;
        end;
    end loop;
    close cur_cargos;
    return;
exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        return;
end;
$$;


ALTER FUNCTION public.mostrar_cargo_empleado_ventas() OWNER TO postgres;

--
-- Name: mostrar_empleado_comision(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mostrar_empleado_comision(e_id integer, e_comision integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
    empleado_nombre rrhh.empleados.nomempleado%type;
    empleado_apellido rrhh.empleados.apeempleado%type;
    empleado_cargo rrhh.cargos.descargo%type;
    empleado_fecha_ingreso rrhh.empleados.feccontrata%type;
    empleado_ventas float;
begin

    select e.nomempleado, e.apeempleado, c.descargo, e.feccontrata,
        sum(pd.cantidad*(pd.preciounidad - (pd.preciounidad*descuento)))
    into empleado_nombre, empleado_apellido, empleado_cargo, empleado_fecha_ingreso, empleado_ventas
    from rrhh.cargos c
    join rrhh.empleados e on e.idcargo = c.idcargo
    join ventas.pedidoscabe pc on pc.idempleado = e.idempleado
    join ventas.pedidosdeta pd on pc.idpedido = pd.idpedido
    where e.idempleado = e_id
   group by e.nomempleado, e.apeempleado, c.descargo, e.feccontrata;
    
	if empleado_nombre is null or empleado_apellido is null or empleado_cargo is null or 
		empleado_fecha_ingreso is null or empleado_ventas is null then
        	raise notice '0';
    else
        raise notice '% % - % - % - % - %', empleado_nombre, empleado_apellido, empleado_cargo, 
            empleado_fecha_ingreso, empleado_ventas, (empleado_ventas * (e_comision/100.0));
    end if;
    return;
exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        return;
end;
$$;


ALTER FUNCTION public.mostrar_empleado_comision(e_id integer, e_comision integer) OWNER TO postgres;

--
-- Name: obtener_cliente_producto(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_cliente_producto(c_id character varying, p_id integer, OUT p_nombre character varying, OUT pc_id integer, OUT pc_fecha timestamp without time zone, OUT pr_razon_social character varying) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
    declare
        cur cursor (c_id ventas.clientes.idcliente%type, p_id compras.productos.idproducto%type) 
            for (
                select p.nomproducto, pc.idpedido, pc.fechapedido, pr.nomproveedor
                    from ventas.clientes c
                    join ventas.pedidoscabe pc on pc.idcliente = c.idcliente
                    join ventas.pedidosdeta pd on pd.idpedido = pc.idpedido
                    join compras.productos p on p.idproducto = pd.idproducto
                    join compras.proveedores pr on pr.idproveedor = p.idproveedor
                    where c.idcliente = c_id and p.idproducto = p_id
                    group by pc.idpedido, p.nomproducto, pc.fechapedido, pr.nomproveedor
        );
        rec record;
    begin
        open cur(c_id,p_id);
        loop
            fetch cur into rec;
            exit when not found;

            p_nombre := rec.nomproducto;
            pc_id := rec.idpedido;
            pc_fecha := rec.fechapedido;
            pr_razon_social := rec.nomproveedor;

            return next;
        end loop;
        close cur;
        return;
    exception
        when others then
            raise notice 'ERROR: %', SQLERRM;
            return;
    end 
    $$;


ALTER FUNCTION public.obtener_cliente_producto(c_id character varying, p_id integer, OUT p_nombre character varying, OUT pc_id integer, OUT pc_fecha timestamp without time zone, OUT pr_razon_social character varying) OWNER TO postgres;

--
-- Name: obtener_producto_proveedores(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_producto_proveedores(p_id integer, OUT p_nombre character varying, OUT pr_razon_social character varying, OUT pr_direccion character varying, OUT pr_telefono character varying) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
declare
    cur cursor (p_id compras.productos.idproducto%type) for (
        select p.nomproducto, pr.nomproveedor, pr.dirproveedor, pr.fonoproveedor
        from compras.productos p
        join compras.proveedores pr on pr.idproveedor = p.idproveedor
        where p.idproducto = p_id
        group by p.nomproducto, pr.nomproveedor, pr.dirproveedor, pr.fonoproveedor
    );
    rec record;
begin
    open cur(p_id);
    loop
        fetch cur into rec;
        exit when not found;

        p_nombre := rec.nomproducto;
	   	pr_razon_social := rec.nomproveedor;
        pr_direccion := rec.dirproveedor;
	   	pr_telefono := rec.fonoproveedor;

        return next;
    end loop;
    close cur;
   	return;
exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        return;
end 
$$;


ALTER FUNCTION public.obtener_producto_proveedores(p_id integer, OUT p_nombre character varying, OUT pr_razon_social character varying, OUT pr_direccion character varying, OUT pr_telefono character varying) OWNER TO postgres;

--
-- Name: obtener_proveedor_productos(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_proveedor_productos(pr_id integer, OUT p_nombre character varying, OUT pr_razon_social character varying, OUT pr_direccion character varying, OUT pr_telefono character varying) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
    declare
        cur cursor (pr_id compras.productos.idproducto%type) for (
            select p.nomproducto, pr.nomproveedor, pr.dirproveedor, pr.fonoproveedor
            from compras.productos p
            join compras.proveedores pr on pr.idproveedor = p.idproveedor
            where p.idproveedor = pr_id
            group by p.nomproducto, pr.nomproveedor, pr.dirproveedor, pr.fonoproveedor
        );
        rec record;
    begin
        open cur(pr_id);
        loop
            fetch cur into rec;
            exit when not found;

            p_nombre := rec.nomproducto;
            pr_razon_social := rec.nomproveedor;
            pr_direccion := rec.dirproveedor;
            pr_telefono := rec.fonoproveedor;

            return next;
        end loop;
        close cur;
        return;
    exception
        when others then
            raise notice 'ERROR: %', SQLERRM;
            return;
    end 
    $$;


ALTER FUNCTION public.obtener_proveedor_productos(pr_id integer, OUT p_nombre character varying, OUT pr_razon_social character varying, OUT pr_direccion character varying, OUT pr_telefono character varying) OWNER TO postgres;

--
-- Name: obtener_total_ordenes(character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_total_ordenes(INOUT c_id character varying, p_anio integer, p_trimestre integer, OUT ordenes integer, OUT precio_total double precision) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin
	select count(pd), sum(pd.cantidad*(pd.preciounidad - (pd.preciounidad*descuento))) 
        from ventas.clientes c 
	    into ordenes, precio_total
	    join ventas.pedidoscabe p on p.idcliente = c.idcliente
	    join ventas.pedidosdeta pd on pd.idpedido = p.idpedido 
	    where c.idcliente = c_id and extract(year from p.fechapedido) = p_anio
	        and extract(quarter from p.fechapedido) = p_trimestre
	    group by p.idpedido;

exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        return;
end 
$$;


ALTER FUNCTION public.obtener_total_ordenes(INOUT c_id character varying, p_anio integer, p_trimestre integer, OUT ordenes integer, OUT precio_total double precision) OWNER TO postgres;

--
-- Name: obtener_total_pedidos(character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.obtener_total_pedidos(INOUT c_id character varying, p_anio integer, p_trimestre integer, OUT pedidos integer, OUT precio_total double precision) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin
    select (
        select count(pc) from ventas.pedidoscabe pc
        where pc.idcliente = c_id and EXTRACT(year FROM pc.fechapedido) = p_anio
            and EXTRACT(quarter FROM pc.fechapedido) = p_trimestre
            ),
            sum(pd.cantidad * (pd.preciounidad - (pd.preciounidad * pd.descuento)))
        from ventas.pedidoscabe p
        into pedidos, precio_total
        join ventas.pedidosdeta pd ON pd.idpedido = p.idpedido
        where p.idcliente = c_id
            and EXTRACT(year from p.fechapedido) = p_anio
            and EXTRACT(quarter from p.fechapedido) = p_trimestre
        group by p.idpedido;

exception
    when others then
        raise notice 'ERROR: %', SQLERRM;
        return;
end 
$$;


ALTER FUNCTION public.obtener_total_pedidos(INOUT c_id character varying, p_anio integer, p_trimestre integer, OUT pedidos integer, OUT precio_total double precision) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categorias; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.categorias (
    idcateria integer NOT NULL,
    nombrecateria character varying(15) NOT NULL,
    descripcion text
);


ALTER TABLE compras.categorias OWNER TO postgres;

--
-- Name: productos; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.productos (
    idproducto integer NOT NULL,
    nomproducto character varying(40) NOT NULL,
    idproveedor integer,
    idcateria integer,
    cantxunidad character varying(20) NOT NULL,
    preciounidad numeric(10,0) NOT NULL,
    unidadesenexistencia smallint NOT NULL,
    unidadesenpedido smallint NOT NULL
);


ALTER TABLE compras.productos OWNER TO postgres;

--
-- Name: proveedores; Type: TABLE; Schema: compras; Owner: postgres
--

CREATE TABLE compras.proveedores (
    idproveedor integer NOT NULL,
    nomproveedor character varying(40) NOT NULL,
    dirproveedor character varying(60) NOT NULL,
    nomcontacto character varying(80) NOT NULL,
    carcontacto character varying(50) NOT NULL,
    idpais character(3),
    fonoproveedor character varying(25) NOT NULL,
    faxproveedor character varying(25) NOT NULL
);


ALTER TABLE compras.proveedores OWNER TO postgres;

--
-- Name: cargos; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.cargos (
    idcargo integer NOT NULL,
    descargo character varying(30) NOT NULL
);


ALTER TABLE rrhh.cargos OWNER TO postgres;

--
-- Name: distritos; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.distritos (
    iddistrito integer NOT NULL,
    nomdistrito character varying(50) NOT NULL
);


ALTER TABLE rrhh.distritos OWNER TO postgres;

--
-- Name: empleados; Type: TABLE; Schema: rrhh; Owner: postgres
--

CREATE TABLE rrhh.empleados (
    idempleado integer NOT NULL,
    apeempleado character varying(50) NOT NULL,
    nomempleado character varying(50) NOT NULL,
    fecnac timestamp without time zone NOT NULL,
    dirempleado character varying(60) NOT NULL,
    iddistrito integer,
    fonoempleado character varying(15),
    idcargo integer,
    feccontrata timestamp without time zone NOT NULL
);


ALTER TABLE rrhh.empleados OWNER TO postgres;

--
-- Name: clientes; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.clientes (
    idcliente character varying(5) NOT NULL,
    nomcliente character varying(40) NOT NULL,
    dircliente character varying(60) NOT NULL,
    idpais character(3),
    fonocliente character varying(25) NOT NULL
);


ALTER TABLE ventas.clientes OWNER TO postgres;

--
-- Name: paises; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.paises (
    idpais character(3) NOT NULL,
    nombrepais character varying(40) NOT NULL
);


ALTER TABLE ventas.paises OWNER TO postgres;

--
-- Name: pedidoscabe; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.pedidoscabe (
    idpedido integer NOT NULL,
    idcliente character varying(5),
    idempleado integer,
    fechapedido timestamp without time zone DEFAULT now() NOT NULL,
    fechaentrega timestamp without time zone,
    fechaenvio timestamp without time zone,
    enviopedido character(1) DEFAULT 0,
    cantidapedido integer,
    destinatario character varying(40),
    dirdestinatario character varying(60),
    ciudestinatario character varying(60),
    refdestnatario character varying(60),
    depdestinatario character varying(60),
    paidestinatario character varying(60)
);


ALTER TABLE ventas.pedidoscabe OWNER TO postgres;

--
-- Name: pedidosdeta; Type: TABLE; Schema: ventas; Owner: postgres
--

CREATE TABLE ventas.pedidosdeta (
    idpedido integer,
    idproducto integer,
    preciounidad numeric(10,0) NOT NULL,
    cantidad smallint NOT NULL,
    descuento double precision NOT NULL
);


ALTER TABLE ventas.pedidosdeta OWNER TO postgres;

--
-- Data for Name: categorias; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.categorias (idcateria, nombrecateria, descripcion) FROM stdin;
\.
COPY compras.categorias (idcateria, nombrecateria, descripcion) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: productos; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.productos (idproducto, nomproducto, idproveedor, idcateria, cantxunidad, preciounidad, unidadesenexistencia, unidadesenpedido) FROM stdin;
\.
COPY compras.productos (idproducto, nomproducto, idproveedor, idcateria, cantxunidad, preciounidad, unidadesenexistencia, unidadesenpedido) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: compras; Owner: postgres
--

COPY compras.proveedores (idproveedor, nomproveedor, dirproveedor, nomcontacto, carcontacto, idpais, fonoproveedor, faxproveedor) FROM stdin;
\.
COPY compras.proveedores (idproveedor, nomproveedor, dirproveedor, nomcontacto, carcontacto, idpais, fonoproveedor, faxproveedor) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: cargos; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.cargos (idcargo, descargo) FROM stdin;
\.
COPY rrhh.cargos (idcargo, descargo) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: distritos; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.distritos (iddistrito, nomdistrito) FROM stdin;
\.
COPY rrhh.distritos (iddistrito, nomdistrito) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: empleados; Type: TABLE DATA; Schema: rrhh; Owner: postgres
--

COPY rrhh.empleados (idempleado, apeempleado, nomempleado, fecnac, dirempleado, iddistrito, fonoempleado, idcargo, feccontrata) FROM stdin;
\.
COPY rrhh.empleados (idempleado, apeempleado, nomempleado, fecnac, dirempleado, iddistrito, fonoempleado, idcargo, feccontrata) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.clientes (idcliente, nomcliente, dircliente, idpais, fonocliente) FROM stdin;
\.
COPY ventas.clientes (idcliente, nomcliente, dircliente, idpais, fonocliente) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: paises; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.paises (idpais, nombrepais) FROM stdin;
\.
COPY ventas.paises (idpais, nombrepais) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: pedidoscabe; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.pedidoscabe (idpedido, idcliente, idempleado, fechapedido, fechaentrega, fechaenvio, enviopedido, cantidapedido, destinatario, dirdestinatario, ciudestinatario, refdestnatario, depdestinatario, paidestinatario) FROM stdin;
\.
COPY ventas.pedidoscabe (idpedido, idcliente, idempleado, fechapedido, fechaentrega, fechaenvio, enviopedido, cantidapedido, destinatario, dirdestinatario, ciudestinatario, refdestnatario, depdestinatario, paidestinatario) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: pedidosdeta; Type: TABLE DATA; Schema: ventas; Owner: postgres
--

COPY ventas.pedidosdeta (idpedido, idproducto, preciounidad, cantidad, descuento) FROM stdin;
\.
COPY ventas.pedidosdeta (idpedido, idproducto, preciounidad, cantidad, descuento) FROM '$$PATH$$/3390.dat';

--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (idcateria);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (idproducto);


--
-- Name: proveedores proveedores_pkey; Type: CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.proveedores
    ADD CONSTRAINT proveedores_pkey PRIMARY KEY (idproveedor);


--
-- Name: cargos cargos_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.cargos
    ADD CONSTRAINT cargos_pkey PRIMARY KEY (idcargo);


--
-- Name: distritos distritos_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.distritos
    ADD CONSTRAINT distritos_pkey PRIMARY KEY (iddistrito);


--
-- Name: empleados empleados_pkey; Type: CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_pkey PRIMARY KEY (idempleado);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (idcliente);


--
-- Name: paises paises_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.paises
    ADD CONSTRAINT paises_pkey PRIMARY KEY (idpais);


--
-- Name: pedidoscabe pedidoscabe_pkey; Type: CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_pkey PRIMARY KEY (idpedido);


--
-- Name: productos productos_idcateria_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_idcateria_fkey FOREIGN KEY (idcateria) REFERENCES compras.categorias(idcateria);


--
-- Name: productos productos_idproveedor_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.productos
    ADD CONSTRAINT productos_idproveedor_fkey FOREIGN KEY (idproveedor) REFERENCES compras.proveedores(idproveedor);


--
-- Name: proveedores proveedores_idpais_fkey; Type: FK CONSTRAINT; Schema: compras; Owner: postgres
--

ALTER TABLE ONLY compras.proveedores
    ADD CONSTRAINT proveedores_idpais_fkey FOREIGN KEY (idpais) REFERENCES ventas.paises(idpais);


--
-- Name: empleados empleados_idcargo_fkey; Type: FK CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_idcargo_fkey FOREIGN KEY (idcargo) REFERENCES rrhh.cargos(idcargo);


--
-- Name: empleados empleados_iddistrito_fkey; Type: FK CONSTRAINT; Schema: rrhh; Owner: postgres
--

ALTER TABLE ONLY rrhh.empleados
    ADD CONSTRAINT empleados_iddistrito_fkey FOREIGN KEY (iddistrito) REFERENCES rrhh.distritos(iddistrito);


--
-- Name: clientes clientes_idpais_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.clientes
    ADD CONSTRAINT clientes_idpais_fkey FOREIGN KEY (idpais) REFERENCES ventas.paises(idpais);


--
-- Name: pedidoscabe pedidoscabe_idcliente_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_idcliente_fkey FOREIGN KEY (idcliente) REFERENCES ventas.clientes(idcliente);


--
-- Name: pedidoscabe pedidoscabe_idempleado_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidoscabe
    ADD CONSTRAINT pedidoscabe_idempleado_fkey FOREIGN KEY (idempleado) REFERENCES rrhh.empleados(idempleado);


--
-- Name: pedidosdeta pedidosdeta_idpedido_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidosdeta
    ADD CONSTRAINT pedidosdeta_idpedido_fkey FOREIGN KEY (idpedido) REFERENCES ventas.pedidoscabe(idpedido);


--
-- Name: pedidosdeta pedidosdeta_idproducto_fkey; Type: FK CONSTRAINT; Schema: ventas; Owner: postgres
--

ALTER TABLE ONLY ventas.pedidosdeta
    ADD CONSTRAINT pedidosdeta_idproducto_fkey FOREIGN KEY (idproducto) REFERENCES compras.productos(idproducto);


--
-- PostgreSQL database dump complete
--

